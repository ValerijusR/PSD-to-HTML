module.exports = {
    localUrl: 'mongodb://localhost/foodorderdb'
};
