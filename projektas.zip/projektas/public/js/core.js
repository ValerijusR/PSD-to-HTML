angular.module('emerilOrder', ['orderController', 'orderService']);
